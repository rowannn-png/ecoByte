import pandas as pd

def dataframe():
    data = {
        "Date" : ["Jan 1", "Jan 1", "Jan 2","Jan 3", "Jan 3", "Jan 4"],
        "Dining Hall" : ["Ban Righ", "Ban Righ", "Jean Royce", "Leonard", "Leonard", "Leonard"],
        "Food": ["Rice", "Chicken", "Bread", "Salad", "Pasta", "Pizza"],
        "Initial": [5.0, 5.0, 5.0, 5.0, 5.0, 5.0],
        "Final" : [1.0, 0.5, 2.0, 3.0, 1.5, 0],
        "Disposed" : [1.0, 1.0, 0.5, 0.5, 0, 0.5]
        }

    df = pd.DataFrame(data)
    return df