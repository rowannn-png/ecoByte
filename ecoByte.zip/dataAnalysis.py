import ecoData
df = ecoData.dataframe()

def analysis(df):
    date = input("Which date would you like to analyze: ")
    hall = input("Which dining hall would you like to analyze: ")

    tempdf = df[df["Dining Hall"].isin([hall])]  
    newdf = tempdf[tempdf["Date"].isin([date])]  
    print("Here is the selected data:")
    print(newdf)

    old = newdf["Initial"].sum()

    new1 = newdf["Final"].sum()
    new2 = newdf["Disposed"].sum()
    new = new1 + new2

    percent = abs(((new-old)/old) * 100)
    return percent

if __name__ == "__main__":
    percent = analysis(df)