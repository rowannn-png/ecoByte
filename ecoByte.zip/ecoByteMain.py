"""
Code of HackHer Hackathon 2024
Rowan, Vivian, Madeleine 
March 9, 2024
"""

import pandas as pd
import cam
import addInfo
import dataAnalysis
import ecoData


def menu():
    df = ecoData.dataframe()
    c = cam.camera()

    while True:
        print(" ")
        choice  = input("Welcome to the Menu. Select a number to proceed: \n1. View Data \n2. Log New Data \n3. Analyze Data \n4. End Program \n")
        
        if choice == "1":
            print(df)

        elif choice == "2":
            new_list = addInfo.loginfo(c)
            df.loc[len(df.index)] = new_list
        
        elif choice == "3":
            percent = dataAnalysis.analysis(df)
            print(f"Food was reduced by {percent}% by the end of the day.")
            print(f"{100-percent}% of the food remains.")
            
        elif choice == "4":
            print("End of Program. Data Exported to Excel.")
            df.to_excel('output.xlsx', index=False)
            break
        else:
            print("Invalid Input.")

menu()