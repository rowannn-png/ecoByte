def loginfo (camInfo):
    print("Please input the following data for your selected food item.")
    date = input("Date: ")
    hall = input("Dining Hall: ")
    food = input("Food item: ")
    initial = float(input (f"Amount of {food} produced at the start of day (kg): "))
    final = float(input (f"Amount of {food} remaining at the end of day (kg): "))
    new_row = {"Date" : date, 
               "Dining Hall" : hall,
               "Food" : food,
               "Initial" : initial,
               "Final" : final,
               "Disposed" : camInfo}
    print("Data Recorded.")
    return new_row