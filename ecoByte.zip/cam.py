import random

def camera():
    camInfo = round(random.uniform(0.1, 5.0), 1)
    return camInfo

if __name__== "__main__":
    num = camera()
    print(num)